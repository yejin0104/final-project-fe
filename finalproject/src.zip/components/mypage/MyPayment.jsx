import Jumbotron from "../templates/Jumbotron";


export default function MyPayment(){
    
    //render
    return (<>
        <Jumbotron subject="결제 내역" detail="내가 결제한 목록"/>
    </>)
}