import Jumbotron from "../templates/Jumbotron";


export default function MyWishList(){

    //render
    return (<>
        <Jumbotron subject="찜목록" detail="내가 찜한 일정 목록"/>
    </>)
}