import { Link, Outlet, useLocation } from "react-router-dom";
import Jumbotron from "../templates/Jumbotron";
import { FaUserShield, FaChartLine, FaMapMarkedAlt, FaExclamationCircle, FaDatabase } from "react-icons/fa";

export default function AdminHome() {
    const location = useLocation();
    const pointColor = "#86C9BB"; // 민트색 포인트

    const menus = [
        { name: "계정 관리", path: "/admin/accounts", icon: <FaUserShield /> },
        { name: "대시보드", path: "/admin/dashboard", icon: <FaChartLine /> },
        { name: "일정 관리", path: "/admin/schedules", icon: <FaMapMarkedAlt /> },
        { name: "장소 DB 관리", path: "/admin/places", icon: <FaDatabase /> },
        { name: "신고 내역", path: "/admin/report", icon: <FaExclamationCircle /> }
    ];

    return (
        <div className="container-fluid py-4" style={{ backgroundColor: "#fbfcfd", minHeight: "100vh" }}>
            <Jumbotron subject="Admin Center" detail="플랫폼 운영 및 데이터 관리 기능을 제공합니다." />

            {/* 메인 네비게이션 탭 */}
            <div className="row mt-4">
                <div className="col">
                    <div className="d-flex gap-2 p-2 bg-white shadow-sm rounded-4 overflow-auto scrollbar-hide">
                        {menus.map((menu) => {
                            const isActive = location.pathname.startsWith(menu.path);
                            return (
                                <Link 
                                    key={menu.path}
                                    to={menu.path} 
                                    className="btn d-flex align-items-center gap-2 px-4 py-3 border-0 rounded-4 transition-all"
                                    style={{
                                        backgroundColor: isActive ? `${pointColor}22` : "transparent",
                                        color: isActive ? pointColor : "#777",
                                        fontWeight: isActive ? "700" : "500",
                                        whiteSpace: "nowrap",
                                        borderBottom: isActive ? `3px solid ${pointColor}` : "3px solid transparent",
                                        borderRadius: "12px"
                                    }}
                                >
                                    <span style={{ fontSize: "1.1rem" }}>{menu.icon}</span>
                                    {menu.name}
                                </Link>
                            );
                        })}
                    </div>
                </div>
            </div>

            {/* 하위 페이지 렌더링 영역 */}
            <div className="row mt-4">
                <div className="col px-3">
                    <div className="fade-in">
                        <Outlet />
                    </div>
                </div>
            </div>

            <style>{`
                .transition-all { transition: all 0.2s ease-in-out; }
                .scrollbar-hide::-webkit-scrollbar { display: none; }
                .fade-in { animation: fadeIn 0.3s ease-in-out; }
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
            `}</style>
        </div>
    );
}