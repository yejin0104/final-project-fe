export const ItemTypes = {
  CARD: 'card',
  MARKER: "marker",
}